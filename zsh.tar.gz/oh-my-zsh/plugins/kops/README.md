# kops

This plugin provides completion for [kops](https://github.com/kubernetes/kops) (Kubernetes Operations),
the command line interface to get a production grade Kubernetes cluster up and running.

To use it, add `kops` to the plugins array in your zshrc file.

```
plugins=(... kops)
```

**Author:** [@nmrony](https://github.com/nmrony)
